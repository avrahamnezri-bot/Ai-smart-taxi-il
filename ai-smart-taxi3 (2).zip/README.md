# AI Smart Taxi (partial package)

This archive contains the project skeleton prepared for Render/GitHub.
